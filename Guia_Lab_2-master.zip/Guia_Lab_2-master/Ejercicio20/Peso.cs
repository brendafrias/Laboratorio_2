﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Peso
    {
        #region Atributes
        private double cantidad;
        private float cotizRespectoDolar;

        #endregion
    }
}
