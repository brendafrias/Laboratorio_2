# Guia_Lab_2

Repository used for the exercises guide v5.0.5.pdf in UTN FRA.
Each folder is a proyect.
