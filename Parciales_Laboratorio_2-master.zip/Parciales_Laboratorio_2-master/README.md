# Parciales_Laboratorio_2
COMO HAGO UN ARRAY DE OBJETOS?!?
